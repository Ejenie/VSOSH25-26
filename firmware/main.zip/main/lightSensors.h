#pragma once
//вкладка для работы с датчиками  линии

void _initLightSensors() {
  pinMode(22, INPUT);
  pinMode(23, INPUT);
  pinMode(24, INPUT);
  pinMode(25, INPUT);
  pinMode(26, INPUT);
  pinMode(27, INPUT);
  pinMode(28, INPUT);
  pinMode(29, INPUT);
}

void _readLine() {
  Serial.println(String(digitalRead(22)) + " " + String(digitalRead(23)) + " " + 
  String(digitalRead(24)) + " " + String(digitalRead(25)) + " " + 
  String(digitalRead(26)) + " " + String(digitalRead(27)) + " " + 
  String(digitalRead(28)) + " " + String(digitalRead(29)));
}