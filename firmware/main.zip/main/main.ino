#include "drivers.h"  //разбиение крда для более удобной работы
#include "servos.h"
#include "serials.h"
#include "leds.h"
#include "lightSensors.h"
#include "conditions.h"
#include "butt.h"

short rightR[2] = { -1, -1 };  //массив направлений моторов рейки, дающих езду вправо
short leftR[2] = { 1, 1 };     //массив направлений моторов рейки, дающих езду влево

short upP[2] = { 1, 1 };      //массив направлений моторов плоттера, дающих езду вверх
short downP[2] = { -1, -1 };  //массив направлений моторов плоттера, дающих езду вниз
short rightP[2] = { -1, 1 };  //массив направлений моторов плоттера, дающих езду вправо
short leftP[2] = { 1, -1 };   //массив направлений моторов плоттера, дающих езду влево

void setup() {
  //инициализация перифирийных устройств
  _initSerials();
  _initMotorsLib();
  _initServos();
  _initLeds();
  _initLightSensors();
  _initButt();

  //код для выполнения тестового задания
  upServo();
  waitWhite();
  on();
  gotoPosRail(rightR, 3600);
  downServo();
  gotoPosPlotter(rightP, 2300);
  gotoPosPlotter(downP, 2300);
  upServo();
  gotoPosRail(leftR, 3600);
}
void loop() {
  planner.tick();
}
